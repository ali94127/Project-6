//
//  mainmenu.cpp
//  SDLProject
//
//  Created by ali on 4/19/20.
//  Copyright © 2020 ctg. All rights reserved.
//

#include "win.h"

#define WIN_WIDTH 1
#define WIN_HEIGHT 1

unsigned int win_data[] =
{
 0
};

void Win::Initialize() {
    
    state.nextScene = -1;
    GLuint mapTextureID = Util::LoadTexture("tileset.png");
    state.map = new Map(WIN_WIDTH, WIN_HEIGHT, win_data, mapTextureID, 1.0f, 4, 1);
    state.player = new Entity();
    state.player->entityType = PLAYER;
    
}
void Win::Update(float deltaTime) {
    
    
}
void Win::Render(ShaderProgram *program) {
    state.map->Render(program);
    Util::DrawText(program, Util::LoadTexture("font1.png"), "YOU WIN!", 0.5f, -0.25f, glm::vec3(3.5, -3, 0));
}
