#include "Level1.h"

#define LEVEL1_WIDTH 14
#define LEVEL1_HEIGHT 8

#define LEVEL1_ENEMY_COUNT 150

unsigned int level1_data[] =
{
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

void Level1::Initialize() {
    
    state.nextScene = -1;
 GLuint mapTextureID = Util::LoadTexture("castleTiles2.png");
 state.map = new Map(LEVEL1_WIDTH, LEVEL1_HEIGHT, level1_data, mapTextureID, 1.0f, 4, 1);
 // Move over all of the player and enemy code from initialization.
    // Initialize Player
    
    state.player = new Entity[4];
    
    state.player[0].entityType = PLAYER;
    state.player[0].position = glm::vec3(1, -1, 0);
    state.player[0].textureID = Util::LoadTexture("spritesheet (2).png");
    state.player[0].animAttack = new int[10] {0, 1, 2, 4, 5, 6, 3, 7, 8, 9};
    
    state.player[1].entityType = PLAYER;
    state.player[1].position = glm::vec3(1, -3, 0);
    state.player[1].textureID = Util::LoadTexture("spritesheet (2).png");
    state.player[1].animAttack = new int[10] {0, 1, 2, 4, 5, 6, 3, 7, 8, 9};
    
    state.player[2].entityType = PLAYER;
    state.player[2].position = glm::vec3(1, -5, 0);
    state.player[2].textureID = Util::LoadTexture("spritesheet (2).png");
    state.player[2].animAttack = new int[10] {0, 1, 2, 4, 5, 6, 3, 7, 8, 9};
    
    state.player[3].entityType = PLAYER;
    state.player[3].position = glm::vec3(1, -7, 0);
    state.player[3].textureID = Util::LoadTexture("spritesheet (2).png");
    state.player[3].animAttack = new int[10] {0, 1, 2, 4, 5, 6, 3, 7, 8, 9};


    state.player[0].animIndices = state.player[0].animAttack;
    state.player[0].animFrames = 10;
    state.player[0].animIndex = 0;
    state.player[0].animTime = 0;
    state.player[0].animCols = 4;
    state.player[0].animRows = 3;
    
    state.player[1].animIndices = state.player[1].animAttack;
    state.player[1].animFrames = 10;
    state.player[1].animIndex = 0;
    state.player[1].animTime = 0;
    state.player[1].animCols = 4;
    state.player[1].animRows = 3;
    
    state.player[2].animIndices = state.player[2].animAttack;
    state.player[2].animFrames = 10;
    state.player[2].animIndex = 0;
    state.player[2].animTime = 0;
    state.player[2].animCols = 4;
    state.player[2].animRows = 3;
    
    state.player[3].animIndices = state.player[3].animAttack;
    state.player[3].animFrames = 10;
    state.player[3].animIndex = 0;
    state.player[3].animTime = 0;
    state.player[3].animCols = 4;
    state.player[3].animRows = 3;
    
    state.player[0].height = 0.8f;
    state.player[0].width = 0.8f;
    
    state.player[1].height = 0.8f;
    state.player[1].width = 0.8f;
    
    state.player[2].height = 0.8f;
    state.player[2].width = 0.8f;
    
    state.player[3].height = 0.8f;
    state.player[3].width = 0.8f;
    
    
    state.enemies = new Entity[LEVEL1_ENEMY_COUNT];
    
    GLuint enemyTextureID = Util::LoadTexture("RedKnight_entity_000_walk_000.png");
    for (int i = 0; i < LEVEL1_ENEMY_COUNT - 1; ++i) {
        int enemy_x = rand() % 198 + 11;
        int enemy_y = rand() % 4;
        enemy_y = -1 - (enemy_y * 2);
        state.enemies[i].entityType = ENEMY;
        state.enemies[i].speed = 2;
        state.enemies[i].aiType = WAITANDGO;
        state.enemies[i].aiState = WALKING;
        state.enemies[i].textureID = enemyTextureID;
        state.enemies[i].height = 0.8f;
        state.enemies[i].width = 0.8f;
        state.enemies[i].position = glm::vec3(enemy_x, enemy_y, 0);
    }
    state.enemies[LEVEL1_ENEMY_COUNT-1].entityType = ENEMY;
    state.enemies[LEVEL1_ENEMY_COUNT-1].speed = 2;
    state.enemies[LEVEL1_ENEMY_COUNT-1].aiType = WAITANDGO;
    state.enemies[LEVEL1_ENEMY_COUNT-1].aiState = WALKING;
    state.enemies[LEVEL1_ENEMY_COUNT-1].textureID = enemyTextureID;
    state.enemies[LEVEL1_ENEMY_COUNT-1].height = 0.8f;
    state.enemies[LEVEL1_ENEMY_COUNT-1].width = 0.8f;
    state.enemies[LEVEL1_ENEMY_COUNT-1].position = glm::vec3(208, -1, 0);
    
    
    //positions
    
    
    
    
    
    state.player[0].animAttackLag = new int[32] {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    state.player[1].animAttackLag = new int[32] {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    state.player[2].animAttackLag = new int[32] {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    state.player[3].animAttackLag = new int[32] {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    
    
}
void Level1::Update(float deltaTime) {
    state.player[0].Update(deltaTime, state.player, state.enemies, LEVEL1_ENEMY_COUNT, state.map);
    state.player[1].Update(deltaTime, state.player, state.enemies, LEVEL1_ENEMY_COUNT, state.map);
    state.player[2].Update(deltaTime, state.player, state.enemies, LEVEL1_ENEMY_COUNT, state.map);
    state.player[3].Update(deltaTime, state.player, state.enemies, LEVEL1_ENEMY_COUNT, state.map);
    
    int dead_enemies = 0;
    for (int i = 0; i < LEVEL1_ENEMY_COUNT; ++i) {
        state.enemies[i].Update(deltaTime, state.player, state.enemies, LEVEL1_ENEMY_COUNT, state.map);
        if ((state.enemies[i].CheckCollision(&state.player[0]) && state.player[0].jump)||(state.enemies[i].CheckCollision(&state.player[1]) && state.player[1].jump)||(state.enemies[i].CheckCollision(&state.player[2]) && state.player[2].jump)||(state.enemies[i].CheckCollision(&state.player[3]) && state.player[3].jump)) {
            state.enemies[i].isActive = false;
        }
        if (state.enemies[i].position.x <= -0.5 && state.enemies[i].isActive) {
            state.enemies[i].isActive = false;
            state.player[0].lives -= 1;
        }
        if (!state.enemies[i].isActive) {
            dead_enemies += 1;
        }
    }
    if (state.player[0].lives <= 0) {
        state.nextScene = 2;
    }
    else if (dead_enemies == LEVEL1_ENEMY_COUNT) {
        state.nextScene = 3;
    }
    
}
void Level1::Render(ShaderProgram *program) {
    state.map->Render(program);
    state.player[0].Render(program);
    state.player[1].Render(program);
    state.player[2].Render(program);
    state.player[3].Render(program);
    
    for (int i = 0; i < LEVEL1_ENEMY_COUNT; ++i) {
        state.enemies[i].Render(program);
    }
    
    Util::DrawText(program, Util::LoadTexture("font1.png"), "LIVES: ", 0.5f, -0.25f, glm::vec3(0.5, -0.25, 0));
    Util::DrawText(program, Util::LoadTexture("font1.png"), std::to_string(state.player[0].lives), 0.5f, -0.25f, glm::vec3(2, -0.25, 0));
    

}
